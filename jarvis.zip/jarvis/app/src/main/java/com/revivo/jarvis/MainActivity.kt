package com.revivo.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), JarvisService.Listener {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var toggle: Button
    private lateinit var anthropicKey: EditText
    private lateinit var userName: EditText
    private lateinit var model: EditText
    private lateinit var sensitivity: SeekBar
    private lateinit var sensLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        status = findViewById(R.id.status)
        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        toggle = findViewById(R.id.toggle)
        anthropicKey = findViewById(R.id.anthropicKey)
        userName = findViewById(R.id.userName)
        model = findViewById(R.id.model)
        sensitivity = findViewById(R.id.sensitivity)
        sensLabel = findViewById(R.id.sensLabel)

        anthropicKey.setText(prefs.anthropicKey)
        userName.setText(prefs.userName)
        model.setText(prefs.model)
        sensitivity.progress = ((prefs.sensitivity - 0.1f) * 100).toInt()
        updateSensLabel()
        sensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateSensLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Button>(R.id.save).setOnClickListener {
            saveSettings()
            Toast.makeText(this, "נשמר", Toast.LENGTH_SHORT).show()
            if (JarvisService.running) {   // restart so new keys/sensitivity take effect
                stopJarvis()
                toggle.postDelayed({ startJarvisChecked() }, 600)
            }
        }
        toggle.setOnClickListener {
            if (JarvisService.running) stopJarvis() else {
                saveSettings()
                startJarvisChecked()
            }
        }
        findViewById<Button>(R.id.talk).setOnClickListener {
            if (!JarvisService.running) {
                Toast.makeText(this, "קודם הפעל את ג'רוויס", Toast.LENGTH_SHORT).show()
            } else {
                startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_TALK))
            }
        }
        findViewById<Button>(R.id.battery).setOnClickListener { askBatteryExemption() }
        findViewById<Button>(R.id.voice).setOnClickListener {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        JarvisService.listeners.add(this)
        logView.text = JarvisService.logLines.joinToString("\n")
        refreshUi()
    }

    override fun onPause() {
        JarvisService.listeners.remove(this)
        super.onPause()
    }

    // ─── service events ───
    override fun onStatus(status: String) = runOnUiThread { refreshUi() }

    override fun onLog(line: String) = runOnUiThread {
        logView.text = JarvisService.logLines.joinToString("\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        refreshUi()
    }

    private fun refreshUi() {
        val on = JarvisService.running
        status.text = if (on) JarvisService.currentStatus else "כבוי"
        toggle.text = if (on) "כבה את ג'רוויס" else "הפעל את ג'רוויס"
    }

    // ─── start / stop ───
    private fun startJarvisChecked() {
        if (!prefs.isConfigured) {
            Toast.makeText(this, "צריך להזין את מפתח Claude API בהגדרות למטה", Toast.LENGTH_LONG).show()
            anthropicKey.requestFocus()
            return
        }
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isEmpty()) startJarvis() else requestPermissions(needed.toTypedArray(), REQ_PERMS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startJarvis()
        } else {
            Toast.makeText(this, "בלי גישה למיקרופון ג'רוויס לא יכול לשמוע אותך", Toast.LENGTH_LONG).show()
        }
    }

    private fun startJarvis() {
        startForegroundService(Intent(this, JarvisService::class.java))
        toggle.postDelayed({ refreshUi() }, 500)
    }

    private fun stopJarvis() {
        stopService(Intent(this, JarvisService::class.java))
        toggle.postDelayed({ refreshUi() }, 300)
    }

    // ─── settings ───
    private fun saveSettings() {
        prefs.anthropicKey = anthropicKey.text.toString()
        prefs.userName = userName.text.toString().ifBlank { "יוסף" }
        prefs.model = model.text.toString()
        prefs.sensitivity = 0.1f + sensitivity.progress / 100f
    }

    private fun updateSensLabel() {
        val v = 0.1f + sensitivity.progress / 100f
        sensLabel.text = "רגישות מילת ההפעלה: ${"%.2f".format(v)}  (גבוה = נדלק בקלות, יותר טעויות)"
    }

    @SuppressLint("BatteryLife")
    private fun askBatteryExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "כבר מאושר ✓", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    companion object {
        private const val REQ_PERMS = 42
    }
}
