package com.revivo.jarvis

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var anthropicKey: String
        get() = sp.getString("anthropic_key", "") ?: ""
        set(v) = sp.edit().putString("anthropic_key", v.trim()).apply()

    var picovoiceKey: String
        get() = sp.getString("picovoice_key", "") ?: ""
        set(v) = sp.edit().putString("picovoice_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    var userName: String
        get() = sp.getString("user_name", "יוסף") ?: "יוסף"
        set(v) = sp.edit().putString("user_name", v.trim()).apply()

    /** 0.0–1.0, higher = wakes more easily (and more false wakes) */
    var sensitivity: Float
        get() = sp.getFloat("sensitivity", 0.6f)
        set(v) = sp.edit().putFloat("sensitivity", v.coerceIn(0.1f, 0.95f)).apply()

    var speechRate: Float
        get() = sp.getFloat("speech_rate", 1.05f)
        set(v) = sp.edit().putFloat("speech_rate", v.coerceIn(0.5f, 2.0f)).apply()

    val isConfigured: Boolean
        get() = anthropicKey.isNotBlank() && picovoiceKey.isNotBlank()

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
    }
}
