package com.revivo.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Minimal client for the Claude Messages API (no external libraries). */
class ClaudeClient(private val apiKey: String, private val model: String) {

    data class Turn(val role: String, val text: String)

    class ApiException(message: String) : IOException(message)

    /** Sends the conversation and returns Claude's spoken-text answer. Call off the main thread. */
    fun ask(system: String, turns: List<Turn>, allowWebSearch: Boolean = true): String {
        var (code, body) = post(buildBody(system, turns, allowWebSearch))
        if (code == 400 && allowWebSearch) {
            // If web search isn't available on this account/model, try once without it
            val retry = post(buildBody(system, turns, false))
            code = retry.first
            body = retry.second
        }
        if (code !in 200..299) {
            val msg = try {
                JSONObject(body).optJSONObject("error")?.optString("message") ?: body
            } catch (e: Exception) {
                body
            }
            throw ApiException("שגיאת API ($code): $msg")
        }
        return extractText(body)
    }

    private fun buildBody(system: String, turns: List<Turn>, withTools: Boolean): JSONObject {
        val messages = JSONArray()
        for (t in turns) {
            messages.put(JSONObject().put("role", t.role).put("content", t.text))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 700)
            .put("system", system)
            .put("messages", messages)
        if (withTools) {
            body.put(
                "tools", JSONArray().put(
                    JSONObject()
                        .put("type", "web_search_20250305")
                        .put("name", "web_search")
                        .put("max_uses", 3)
                )
            )
        }
        return body
    }

    private fun post(body: JSONObject): Pair<Int, String> {
        val conn = URL(API_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            conn.disconnect()
        }
    }

    private fun extractText(body: String): String {
        val content = JSONObject(body).optJSONArray("content") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") {
                sb.append(block.optString("text"))
            }
        }
        return sb.toString().trim()
    }

    companion object {
        private const val API_URL = "https://api.anthropic.com/v1/messages"
    }
}
