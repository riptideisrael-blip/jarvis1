package com.revivo.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Runs in the background with a notification:
 * wake word "Jarvis" → listen (Hebrew) → ask Claude → speak the answer (Hebrew) → listen for a follow-up → back to wake word.
 */
class JarvisService : Service() {

    private enum class State { WAITING, LISTENING, THINKING, SPEAKING, STOPPED }

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private var wake: WakeWordEngine? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var tone: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var state = State.STOPPED
    private var followUp = false
    private val history = mutableListOf<ClaudeClient.Turn>()
    private var lastInteraction = 0L

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        createChannel()
        goForeground("מתחיל…")
        running = true
        tone = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            null
        }
        initTts()
        startWakeWord()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TALK -> main.post { onWake() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        state = State.STOPPED
        running = false
        main.removeCallbacksAndMessages(null)
        try { wake?.release() } catch (_: Exception) {}
        wake = null
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tone?.release()
        releaseWakeLock()
        worker.shutdownNow()
        log("ג'רוויס כבוי")
        super.onDestroy()
    }

    // ───────────────────────── wake word ─────────────────────────

    private fun startWakeWord() {
        if (state == State.STOPPED && !running) return
        state = State.WAITING
        followUp = false
        releaseWakeLock()
        try {
            if (wake == null) {
                wake = WakeWordEngine(
                    applicationContext,
                    onWake = { main.post { onWake() } },
                    onError = { msg ->
                        main.post {
                            log(msg)
                            setStatus("שגיאה במילת ההפעלה")
                        }
                    }
                )
            }
            wake?.threshold = 1f - prefs.sensitivity
            wake?.start()
            setStatus("מקשיב ל\"היי ג'רוויס\"")
        } catch (e: Exception) {
            setStatus("שגיאה במילת ההפעלה")
            log("שגיאה בטעינת מילת ההפעלה: ${e.message}")
        }
    }

    private fun stopWakeWord() {
        try { wake?.stop() } catch (_: Exception) {}
    }

    private fun onWake() {
        when (state) {
            State.SPEAKING -> tts?.stop()          // "Jarvis" while speaking = interrupt
            State.LISTENING, State.THINKING -> return
            State.STOPPED -> return
            State.WAITING -> {}
        }
        stopWakeWord()
        acquireWakeLock()
        if (System.currentTimeMillis() - lastInteraction > CONTEXT_TIMEOUT_MS) history.clear()
        beep()
        followUp = false
        main.postDelayed({ startListening() }, 350)
    }

    // ───────────────────────── speech → text ─────────────────────────

    private fun startListening() {
        state = State.LISTENING
        setStatus(if (followUp) "ממשיך להקשיב…" else "כן, יוסף?")
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("זיהוי דיבור לא זמין בטלפון — צריך להתקין/לעדכן את אפליקציית Google")
            backToWakeWord()
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "he-IL")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        recognizer?.startListening(intent)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (state != State.LISTENING) return
            val silent = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_NO_MATCH
            if (!silent) log("שגיאת זיהוי דיבור (קוד $error)")
            backToWakeWord()
        }

        override fun onResults(results: Bundle?) {
            if (state != State.LISTENING) return
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (text.isEmpty()) backToWakeWord() else handleUserText(text)
        }
    }

    // ───────────────────────── Claude ─────────────────────────

    private fun handleUserText(text: String) {
        log("אתה: $text")
        lastInteraction = System.currentTimeMillis()

        if (isGoodbye(text)) {
            speak("בשמחה.", listenAfter = false)
            history.clear()
            return
        }

        state = State.THINKING
        setStatus("חושב…")
        history.add(ClaudeClient.Turn("user", text))
        trimHistory()
        val turns = history.toList()
        val system = systemPrompt()
        val client = ClaudeClient(prefs.anthropicKey, prefs.model)

        worker.execute {
            val reply = try {
                client.ask(system, turns)
            } catch (e: Exception) {
                main.post {
                    log("שגיאה: ${e.message}")
                    history.removeLastOrNull()
                    speak("סליחה, יש לי בעיה להתחבר כרגע.", listenAfter = false)
                }
                return@execute
            }
            main.post {
                if (state != State.THINKING) return@post
                val spoken = cleanForSpeech(reply).ifEmpty { "לא הצלחתי למצוא תשובה." }
                history.add(ClaudeClient.Turn("assistant", spoken))
                lastInteraction = System.currentTimeMillis()
                log("ג'רוויס: $spoken")
                speak(spoken, listenAfter = true)
            }
        }
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d בMMMM yyyy, HH:mm", Locale("he", "IL")).format(Date())
        val name = prefs.userName
        return """
            אתה ג'רוויס, העוזר האישי הקולי של $name. הוא מדבר איתך בקול דרך הטלפון, והתשובות שלך מוקראות לו בקול.

            איך לדבר:
            - עברית טבעית ומדוברת. קצר: בדרך כלל משפט עד שלושה, אלא אם ביקש פירוט.
            - בלי רשימות, כותרות, סימני עיצוב, קישורים או אימוג'י — רק טקסט שנשמע טוב בקול.
            - טון: אדיב, חד, בטוח בעצמו, עם קורטוב הומור יבש — כמו ג'רוויס מאיירון מן. לא חנפן.
            - אם לא שמעת טוב או שהבקשה לא ברורה, שאל שאלה קצרה אחת.
            - כשצריך מידע עדכני (מזג אוויר, חדשות, שעות פתיחה, מחירים) — חפש ברשת ותן את השורה התחתונה.
            - אם מבקשים ממך פעולה שאין לך יכולת לבצע מכאן (לקבוע ביומן, לשלוח הודעה), אמור זאת בפשטות.

            עכשיו: $now (שעון ישראל).
        """.trimIndent()
    }

    private fun trimHistory() {
        while (history.size > MAX_TURNS) history.removeAt(0)
        // Conversation must start with a user turn
        while (history.isNotEmpty() && history.first().role != "user") history.removeAt(0)
    }

    private fun isGoodbye(text: String): Boolean {
        val t = text.replace(Regex("[.!?,]"), "").trim()
        return t in setOf("תודה", "תודה רבה", "זהו", "זה הכל", "ביי", "סיום", "תודה ג'רוויס", "לא תודה", "זהו תודה")
    }

    private fun cleanForSpeech(s: String): String =
        s.replace(Regex("[*#`_>|]"), "")
            .replace(Regex("\\[(.*?)]\\((.*?)\\)"), "$1")
            .replace(Regex("https?://\\S+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    // ───────────────────────── text → speech ─────────────────────────

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("he", "IL")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    log("אין קול עברי מותקן — הגדרות ← נגישות/שפה ← המרת טקסט לדיבור ← התקן עברית")
                }
                tts?.setSpeechRate(prefs.speechRate)
                ttsReady = true
            } else {
                log("מנוע הדיבור לא נטען")
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                main.post { afterSpeaking(utteranceId) }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { afterSpeaking(utteranceId) }
            }
        })
    }

    private fun speak(text: String, listenAfter: Boolean) {
        state = State.SPEAKING
        setStatus("מדבר…")
        if (!ttsReady) {
            log("(הקראה לא זמינה) $text")
            backToWakeWord()
            return
        }
        val id = if (listenAfter) UTT_FOLLOW else UTT_END
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), id)
    }

    private fun afterSpeaking(id: String?) {
        if (state != State.SPEAKING) return
        if (id == UTT_FOLLOW) {
            followUp = true
            main.postDelayed({ if (state == State.SPEAKING) startListening() }, 250)
        } else {
            backToWakeWord()
        }
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun backToWakeWord() {
        recognizer?.cancel()
        state = State.WAITING
        // Give the microphone a moment to be released by the recognizer
        main.postDelayed({ if (state == State.WAITING) startWakeWord() }, 400)
    }

    private fun beep() {
        try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 140) } catch (_: Exception) {}
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:conversation").also {
            it.acquire(3 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "ג'רוויס פעיל", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val talk = PendingIntent.getService(
            this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_TALK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("ג'רוויס")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "דבר", talk).build())
            .addAction(Notification.Action.Builder(null, "כבה", stop).build())
            .build()
    }

    private fun goForeground(text: String) {
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun setStatus(text: String) {
        currentStatus = text
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        listeners.forEach { it.onStatus(text) }
    }

    private fun log(line: String) {
        main.post {
            logLines.add(line)
            while (logLines.size > 60) logLines.removeAt(0)
            listeners.forEach { it.onLog(line) }
        }
    }

    // ───────────────────────── UI bridge ─────────────────────────

    interface Listener {
        fun onStatus(status: String)
        fun onLog(line: String)
    }

    companion object {
        const val ACTION_STOP = "com.revivo.jarvis.STOP"
        const val ACTION_TALK = "com.revivo.jarvis.TALK"
        private const val CHANNEL_ID = "jarvis"
        private const val NOTIF_ID = 7
        private const val UTT_FOLLOW = "follow"
        private const val UTT_END = "end"
        private const val MAX_TURNS = 16
        private const val CONTEXT_TIMEOUT_MS = 5 * 60 * 1000L

        @Volatile var running = false
        var currentStatus = "כבוי"
        val logLines = mutableListOf<String>()
        val listeners = mutableSetOf<Listener>()
    }
}
