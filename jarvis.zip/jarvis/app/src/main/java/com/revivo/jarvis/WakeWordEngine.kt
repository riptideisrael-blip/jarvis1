package com.revivo.jarvis

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.nio.FloatBuffer

/**
 * On-device "hey Jarvis" detector (openWakeWord models, no account or key needed).
 * Pipeline per 80 ms of 16 kHz audio: raw audio → mel spectrogram → speech embedding → wake-word score.
 */
class WakeWordEngine(
    private val context: Context,
    private val onWake: () -> Unit,
    private val onError: (String) -> Unit,
) {
    /** Score needed to trigger (0–1). Lower = wakes more easily. */
    @Volatile var threshold: Float = 0.5f

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var melSession: OrtSession? = null
    private var embSession: OrtSession? = null
    private var wwSession: OrtSession? = null

    @Volatile private var running = false
    private var thread: Thread? = null

    val isRunning: Boolean get() = running

    fun start() {
        if (running) return
        loadModels()
        running = true
        thread = Thread({ loop() }, "jarvis-wakeword").also { it.start() }
    }

    /** Stops listening and waits until the microphone is released. Safe to call from the main thread. */
    fun stop() {
        running = false
        val t = thread
        if (t != null && t != Thread.currentThread()) {
            try { t.join(1500) } catch (_: InterruptedException) {}
        }
        thread = null
    }

    fun release() {
        stop()
        melSession?.close(); melSession = null
        embSession?.close(); embSession = null
        wwSession?.close(); wwSession = null
    }

    private fun loadModels() {
        if (melSession != null) return
        melSession = open("melspectrogram.onnx")
        embSession = open("embedding_model.onnx")
        wwSession = open("hey_jarvis_v0.1.onnx")
    }

    private fun open(asset: String): OrtSession {
        val bytes = context.assets.open(asset).use { it.readBytes() }
        return env.createSession(bytes, OrtSession.SessionOptions())
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, CHUNK * 2 * 4)
            )
        } catch (e: Exception) {
            running = false
            onError("לא ניתן לפתוח את המיקרופון: ${e.message}")
            return
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            running = false
            onError("המיקרופון תפוס או לא זמין")
            return
        }

        val pcm = ShortArray(CHUNK)
        val raw = FloatArray(CHUNK + CONTEXT)                 // previous 480 samples + new 1280
        val mel = ArrayDeque<FloatArray>()
        repeat(MEL_WINDOW) { mel.addLast(FloatArray(MEL_BINS) { 1f }) }
        val embeddings = ArrayDeque<FloatArray>()
        var chunks = 0
        var cooldown = 0

        try {
            recorder.startRecording()
            while (running) {
                var read = 0
                while (read < CHUNK && running) {
                    val n = recorder.read(pcm, read, CHUNK - read)
                    if (n <= 0) {
                        running = false
                        onError("שגיאה בקריאה מהמיקרופון ($n)")
                        break
                    }
                    read += n
                }
                if (!running) break

                System.arraycopy(raw, CHUNK, raw, 0, CONTEXT)
                for (i in 0 until CHUNK) raw[CONTEXT + i] = pcm[i].toFloat()

                for (frame in melFrames(raw)) {
                    mel.addLast(frame)
                    if (mel.size > MEL_WINDOW) mel.removeFirst()
                }
                embeddings.addLast(embed(mel))
                if (embeddings.size > EMB_WINDOW) embeddings.removeFirst()
                chunks++

                if (cooldown > 0) { cooldown--; continue }
                if (embeddings.size < EMB_WINDOW || chunks < WARMUP_CHUNKS) continue

                if (score(embeddings) >= threshold) {
                    cooldown = 20
                    running = false        // exit the loop and free the mic before the callback runs
                    onWake()
                }
            }
        } catch (e: Exception) {
            running = false
            onError("שגיאה במנוע מילת ההפעלה: ${e.message}")
        } finally {
            try { recorder.stop() } catch (_: Exception) {}
            recorder.release()
        }
    }

    private fun melFrames(audio: FloatArray): List<FloatArray> {
        val input = OnnxTensor.createTensor(env, FloatBuffer.wrap(audio), longArrayOf(1, audio.size.toLong()))
        input.use {
            melSession!!.run(mapOf(melSession!!.inputNames.first() to input)).use { res ->
                val buf = (res.get(0) as OnnxTensor).floatBuffer
                val frames = buf.remaining() / MEL_BINS
                val out = ArrayList<FloatArray>(frames)
                for (f in 0 until frames) {
                    out.add(FloatArray(MEL_BINS) { buf.get() / 10f + 2f })
                }
                return out
            }
        }
    }

    private fun embed(mel: ArrayDeque<FloatArray>): FloatArray {
        val flat = FloatArray(MEL_WINDOW * MEL_BINS)
        var i = 0
        for (frame in mel) { System.arraycopy(frame, 0, flat, i, MEL_BINS); i += MEL_BINS }
        val input = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(flat), longArrayOf(1, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1)
        )
        input.use {
            embSession!!.run(mapOf(embSession!!.inputNames.first() to input)).use { res ->
                val buf = (res.get(0) as OnnxTensor).floatBuffer
                return FloatArray(buf.remaining()) { buf.get() }
            }
        }
    }

    private fun score(embeddings: ArrayDeque<FloatArray>): Float {
        val dim = embeddings.first().size
        val flat = FloatArray(EMB_WINDOW * dim)
        var i = 0
        for (e in embeddings) { System.arraycopy(e, 0, flat, i, dim); i += dim }
        val input = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(flat), longArrayOf(1, EMB_WINDOW.toLong(), dim.toLong())
        )
        input.use {
            wwSession!!.run(mapOf(wwSession!!.inputNames.first() to input)).use { res ->
                return (res.get(0) as OnnxTensor).floatBuffer.get()
            }
        }
    }

    companion object {
        private const val SAMPLE_RATE = 16_000
        private const val CHUNK = 1280          // 80 ms
        private const val CONTEXT = 480         // extra samples so each chunk yields 8 mel frames
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76
        private const val EMB_WINDOW = 16
        private const val WARMUP_CHUNKS = 20
    }
}
